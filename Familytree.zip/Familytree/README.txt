This README file explains how to use Family Tree program. 

Running in an IDE
---------------------

If you want to run the application in an IDE, such as Eclipse, you should
be able to import the entire project into a project in the IDE. Alternatively 
you can copy entire source files into existing java project. After this add dependencies into classpath and
then run ApplicationRuunner.java to run application .

                  
Run using executable JAR file
------------------------------
                  
If you find it easier to run programs by double-clicking, you can
use executable jar files to run the application. There is executable jar file "myjar.jar"
which can be used to run the application.

Use the command - java -jar myjar.jar
Pointing to the main folder.
