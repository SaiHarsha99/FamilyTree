package com.tree.exception;

public class DuplicatePersonFoundException extends Exception {
	
	public DuplicatePersonFoundException(String message)
	{
		super(message);
	}

}
