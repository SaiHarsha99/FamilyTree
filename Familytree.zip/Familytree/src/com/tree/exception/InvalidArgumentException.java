package com.tree.exception;

public class InvalidArgumentException extends Exception {
	
	public InvalidArgumentException(String message)
	{
		super(message);
	}

}
