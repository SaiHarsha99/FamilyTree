package com.tree.exception;

public class InvalidRelationEnteredException extends Exception {
	
	public InvalidRelationEnteredException(String message)
	{
		super(message);
	}

}
