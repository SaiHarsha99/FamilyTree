package com.tree.exception;

public class NoMemberFoundException extends Exception {
	
	public NoMemberFoundException(String message)
	{
		super(message);
	}

}
