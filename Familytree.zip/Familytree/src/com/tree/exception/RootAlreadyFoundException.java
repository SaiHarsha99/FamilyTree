package com.tree.exception;

public class RootAlreadyFoundException extends Exception {
	
	public RootAlreadyFoundException(String message)
	{
		super(message);
	}

}
