package com.tree.family;

public enum GENDER {

	MALE,FEMALE;
}
